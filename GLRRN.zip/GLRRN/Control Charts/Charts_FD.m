function [N,t,G1,G2]=Charts_FD(lambda,alpha,delta,theta1,theta2,p) 
X=0;
X1=0;
N=0;
N1=0;
Z=1+exprnd(lambda);
t=fix(Z/delta);
while (X<=1)&&(X>=0)
 N=N+1;  
 U=rand;
 X=(1-alpha)*X+alpha*((N<=t)*(2*U-1)+(N>t)*2*U-theta1)/(theta2-theta1);
end

while (X1<=1)&&(X1>=0)
 N1=N1+1;  
 U=rand;
 X1=(1-alpha)*X1+alpha*((N1<=t)*(2*U-1)+(N1>t)*2*U-theta1)/(theta2+p-theta1);
end
G1=(N1-N)/p;
G2=((N1>t)*(N1-t)-(N>t)*(N-t))/p;
end