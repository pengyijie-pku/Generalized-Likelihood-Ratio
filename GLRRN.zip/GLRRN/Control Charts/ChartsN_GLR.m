function [G1,G2]=ChartsN_GLR(N,lambda,alpha,delta,theta1,theta2) 
X=zeros(1,N+1);
X(1)=0.5;
U=rand(1,N);
Z=1+exprnd(lambda);
t=fix(Z/delta);
for n=1:N
 X(n+1)=(1-alpha)*X(n)+alpha*((n<=t)*(2*U(n)-1)+(n>t)*2*U(n)-theta1)/(theta2-theta1);
end
Z0=zeros(1,N);
Z0(1:N-1)=(X(2:end-1)>=0).*(X(2:end-1)<=1);
Z0(N)=1-(X(end)>=0).*(X(end)<=1);
V1=repmat(U,N,1);
V2=repmat(U,N,1);
for n=1:N
V1(n,n)=1;
V2(n,n)=0;
end
Y1=zeros(N,N+1);
Y2=zeros(N,N+1);
R1=zeros(1,N);
R2=zeros(1,N);
for n=1:N
Y1(:,n+1)=(1-alpha)*Y1(:,n)+alpha*((n<=t)*(2*V1(:,n)-1)+(n>t)*2*V1(:,n)-theta1)/(theta2-theta1);  
R1(n)=-((n<=t)/2+(n>t)-theta1/2)/(theta2-theta1);  
Y2(:,n+1)=(1-alpha)*Y2(:,n)+alpha*((n<=t)*(2*V2(:,n)-1)+(n>t)*2*V2(:,n)-theta1)/(theta2-theta1); 
R2(n)=((n<=t)+theta1)/2/(theta2-theta1);  
end
Z1=zeros(N,N);
Z2=zeros(N,N);
Z1(:,1:end-1)=(Y1(:,2:end-1)>=0).*(Y1(:,2:end-1)<=1);
Z2(:,1:end-1)=(Y2(:,2:end-1)>=0).*(Y2(:,2:end-1)<=1);
Z1(:,end)=1-(Y1(:,end)>=0).*(Y1(:,end)<=1);
Z2(:,end)=1-(Y2(:,end)>=0).*(Y2(:,end)<=1);
A1=prod(Z1,2);
A2=prod(Z2,2);
R=R1*A1-R2*A2;
D=prod(Z0)*N/(theta2-theta1);
G1=N*(R+D);
G2=(N>t)*(N-t)*(R+D);
end