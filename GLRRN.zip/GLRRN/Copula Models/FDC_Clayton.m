function [X1,X2]=FDC_Clayton(theta,k,d,num)
%tic
Y1=gamrnd(1/theta,1,1,num);
Y2=gamrnd(1/(theta+d),1,1,num);
U2=rand(k,num);
X1=(1-log(U2)./repmat(Y1,k,1)).^(-1/theta);
X2=(1-log(U2)./repmat(Y2,k,1)).^(-1/(theta+d));
%toc
end