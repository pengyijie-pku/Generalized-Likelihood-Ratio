function D=BDS_FD(r,T,l,theta,k,d,num)
[X1,X2]=FDC_AMH(theta,k,d,num);
[L,lambda]=Loss_Lambda(k,num);
Z1=-log(X1)./lambda;
[t1,I1]=sort(Z1);
Z2=-log(X2)./lambda;
[t2,I2]=sort(Z2);
L1=L(I1);
L2=L(I2);
D=(L2(l,:).*exp(-r*t2(l,:)).*(t2(l,:)<T)-L1(l,:).*exp(-r*t1(l,:)).*(t1(l,:)<T))/d;
end 