function [X1,X2]=FD_Clayton(theta,k,d,num)
Y1=gamrnd(1/theta,1,1,num);
Y2=gamrnd(1/(theta+d),1,1,num);
X1=(1-log(rand(k,num))./repmat(Y1,k,1)).^(-1/theta);
X2=(1-log(rand(k,num))./repmat(Y2,k,1)).^(-1/(theta+d));
end