function [X,W]=GLR_Clayton(theta,k,num)
%tic
Y=gamrnd(1/theta,1,1,num);
W=zeros(1,num);
 U=rand(k,num);
 V=-log(U)./repmat(Y,k,1);
 X=(1+V).^(-1/theta);
for i=1:k
 A=(1+(1-(V(i,:)+1).*Y).*log(1+V(i,:)))/theta;
 W=W+A;
end
B=psi(1/theta)/theta^2-log(Y)/theta^2;
W=W+B;
%toc
end