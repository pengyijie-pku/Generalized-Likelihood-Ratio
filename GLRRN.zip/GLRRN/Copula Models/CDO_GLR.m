function D=CDO_GLR(T,u,l,theta,k,num)
[X,W]=QGLR_Clayton(theta,k,num);
%[X,W]=QGLR_AMH(theta,k,num);
[L,lambda]=Loss_Lambda(k,num);
TL=sum(L(:,1));
Z=-log(X)./lambda;
LL=sum(L.*(Z<T));
D=((LL-l*TL).*(LL>l*TL)-(LL-u*TL).*(LL>u*TL)).*W;
end 