function [X,W]=QGLR_Clayton(theta,k,num)
 S = sobolset(k+1,'Skip',1e3,'Leap',1e2);
 S= scramble(S,'MatousekAffineOwen');
 P= net(S,num);
 U=P';
Y=gaminv(U(1,:),1/theta,1);
W=zeros(1,num);
 V=-log(U(2:end,:))./repmat(Y,k,1);
 X=(1+V).^(-1/theta);
for i=1:k
 A=(1+(1-(V(i,:)+1).*Y).*log(1+V(i,:)))/theta;
 W=W+A;
end
B=psi(1/theta)/theta^2-log(Y)/theta^2;
W=W+B;
end