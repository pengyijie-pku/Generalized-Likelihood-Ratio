function D=BDS_GLR(r,T,l,theta,k,num)
[X,W]=GLR_AMH(theta,k,num);
[L,lambda]=Loss_Lambda(k,num);
Z=-log(X)./lambda;
[t,I]=sort(Z);
SL=L(I);
D=SL(l,:).*exp(-r*t(l,:)).*(t(l,:)<T).*W;
end 