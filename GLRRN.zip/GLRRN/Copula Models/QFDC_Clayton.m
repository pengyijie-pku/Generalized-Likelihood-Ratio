function [X1,X2]=QFDC_Clayton(theta,k,d,num)
%tic
 S = sobolset(k+1,'Skip',1e3,'Leap',1e2);
 S= scramble(S,'MatousekAffineOwen');
 P= net(S,num);
 U=P';
Y1=gaminv(U(1,:),1/theta,1);
Y2=gaminv(U(1,:),1/(theta+d),1);
X1=(1-log(U(2:end,:))./repmat(Y1,k,1)).^(-1/theta);
X2=(1-log(U(2:end,:))./repmat(Y2,k,1)).^(-1/(theta+d));
%toc
end