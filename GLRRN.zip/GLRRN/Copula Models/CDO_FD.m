function D=CDO_FD(T,u,l,theta,k,d,num)
%[X1,X2]=FDC_Clayton(theta,k,d,num);
[X1,X2]=FDC_AMH(theta,k,d,num);
[L,lambda]=Loss_Lambda(k,num);
TL=sum(L(:,1));
Z1=-log(X1)./lambda;
Z2=-log(X2)./lambda;
LL1=sum(L.*(Z1<T));
LL2=sum(L.*(Z2<T));
D=(((LL2-l*TL).*(LL2>l*TL)-(LL2-u*TL).*(LL2>u*TL))-((LL1-l*TL).*(LL1>l*TL)-(LL1-u*TL).*(LL1>u*TL)))/d;
end 