function [X1,X2]=FDC_AMH(theta,k,d,num)
%tic
Y1=geornd(1-theta,1,num)+1;
Y2=geornd(1-theta-d,1,num)+1;
U2=rand(k,num);
V1=-log(U2)./repmat(Y1,k,1);
V2=-log(U2)./repmat(Y2,k,1);
X1=(1-theta)./(exp(V1)-theta);
X2=(1-theta-d)./(exp(V2)-theta-d);
%toc
end