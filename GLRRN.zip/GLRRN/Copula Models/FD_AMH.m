function [X1,X2]=FD_AMH(theta,k,d,num)
Y1=geornd(1-theta,1,num)+1;
Y2=geornd(1-theta-d,1,num)+1;
X1=(1-theta)./(exp(-log(rand(k,num))./repmat(Y1,k,1))-theta);
X2=(1-theta-d)./(exp(-log(rand(k,num))./repmat(Y2,k,1))-theta-d);
end