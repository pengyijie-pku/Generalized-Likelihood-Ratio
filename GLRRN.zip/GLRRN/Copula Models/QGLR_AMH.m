function [X,W]=QGLR_AMH(theta,k,num)
%tic
Y=geornd(1-theta,1,num)+1;
W=zeros(1,num);
 %U=rand(k,num);
  S = sobolset(k,'Skip',1e3,'Leap',1e2);
 S= scramble(S,'MatousekAffineOwen');
 P= net(S,num);
 U=P';
 V=-log(U)./repmat(Y,k,1);
  Z=exp(V);
  X=(1-theta)./(Z-theta);
for i=1:k
 A=1/(1-theta)-2./(Z(i,:)-theta)+(Y-(Z(i,:)+theta)./(Z(i,:)-theta)).*(1-1./Z(i,:))/(1-theta);
 W=W+A;
end
B=1/(theta-1)+(Y-1)/theta;
W=W+B;
%toc
end