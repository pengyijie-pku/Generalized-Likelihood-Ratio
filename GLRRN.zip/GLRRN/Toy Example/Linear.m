function [g,g11,g12,g21,g22]=Linear(z,num,theta,lambda1,lambda2) 
%G=zeros(1,4);
l=length(z);
U1=rand(1,num);
U2=rand(1,num);
U1=repmat(U1,l,1);
U2=repmat(U2,l,1);
z=repmat(z',1,num);
g=-theta*log(U1)/lambda1-log(U2)/lambda2;
g11=-(g<=z).*(log(U1)+1)/theta;
g12=lambda2*((-theta*log(U1)/lambda1<=z).*log(U1)-(g<=z).*log(U1))/lambda1; 
g21=lambda1*((-log(U2)/lambda2<=z)-(g<=z))/theta;
g22=lambda2*((-theta*log(U1)/lambda1<=z)-(g<=z));
end