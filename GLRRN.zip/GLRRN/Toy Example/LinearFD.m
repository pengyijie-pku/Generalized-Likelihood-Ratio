function [G1,G2]=LinearFD(z,num,theta,lambda1,lambda2,delta) 
tic
%G=zeros(1,4);
l=length(z);
U1=rand(1,num);
U2=rand(1,num);
U1=repmat(U1,l,1);
U2=repmat(U2,l,1);
z1=z+delta;
z=repmat(z',1,num);
z1=repmat(z1',1,num);
g=-theta*log(U1)/lambda1-log(U2)/lambda2;
g1=-(theta+delta)*log(U1)/lambda1-log(U2)/lambda2;
G1=((g1<=z)-(g<=z))/delta;
G2=((g<=z1)-(g<=z))/delta;
toc
end