function [g,g11,g12,g21,g22]=Linear2(z,num,theta,lambda1,lambda2) 
%G=zeros(1,4);
tic
l=length(z);
U1=rand(1,num);
U2=rand(1,num);
U1=repmat(U1,l,1);
U2=repmat(U2,l,1);
z=repmat(z',1,num);
g=-theta*log(U1)/lambda1-log(U2)/lambda2;
g11=-(1-exp(-lambda2*(z+theta*log(U1)/lambda1).*(z+theta*log(U1)/lambda1>0))).*(log(U1)+1)/theta;
g12=lambda1*lambda2*((z/theta+1/lambda1).*exp(-lambda1*z/theta)-((z+log(U2)/lambda2).*(z+log(U2)/lambda2>0)/theta+1/lambda2).*exp(-lambda1*(z+log(U2)/lambda2).*(z+log(U2)/lambda2>0)/theta)); 
g21=lambda1*(exp(-lambda2*(z+theta*log(U1)/lambda1).*(z+theta*log(U1)/lambda1>0))-exp(-lambda2*z))/theta;
g22=lambda2*(exp(-lambda1*(z+log(U2)/lambda2).*(z+log(U2)/lambda2>0)/theta)-exp(-lambda1*z/theta));
toc
end