function D=GLR(theta)
p=0.4;
DW=0;
n=geornd(p)+1;
U1=rand(1,n);
U2=rand(1,n);
t=U2.*(1-U2);
w=(4*t).^(theta-1);
dw=w.*log(4*t);
Ix=zeros(1,n);
Ix(1:n-1)=(U1(1:n-1)>w(1:n-1));
Ix(n)=(U1(n)<=w(n));
if sum(Ix)==n
 DW=dw(n)-sum(dw(1:n-1));   
else
if sum(Ix)>=n-1
 I=find(Ix==0);
 if I~=n
  DW=-dw(I);
 else
  DW=dw(I); 
 end
end
end
D=DW*(U2(n))^2/geopdf(n-1,p);
end

