function D=FD(theta,d)
U1=rand(1,1);
U2=rand(1,1);
w=(4*U2*(1-U2))^(theta-1);
while U1>w
U1=rand(1,1);
U2=rand(1,1);
w=(4*U2*(1-U2))^(theta-1);
end

U1=rand(1,1);
U3=rand(1,1);
w=(4*U3*(1-U3))^(theta-1+d);
while U1>w
U1=rand(1,1);
U3=rand(1,1);
w=(4*U3*(1-U3))^(theta-1+d);
end

D=(U3-U2)/d;
end