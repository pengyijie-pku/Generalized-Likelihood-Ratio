function [D,x2]=FD(n,x,d,delta,theta)
U=rand(1,n);
N=delta*normrnd(0,1,1,n);
x1=x;
x2=x;
for i=1:n
y1=x1+N(i);
y2=x2+N(i);
R1=exp(((x1-theta-d)^2-(y1-theta-d)^2)/2);
R2=exp(((x2-theta)^2-(y2-theta)^2)/2);
w1=min(1,R1);
w2=min(1,R2);
x1=(U(i)>w1)*x1+(U(i)<=w1).*y1;
x2=(U(i)>w2)*x2+(U(i)<=w2).*y2;
end
%D=(x1-x2)/d;
D=(x1.^2-x2.^2)/d;
end