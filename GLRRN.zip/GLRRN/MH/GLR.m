function D=GLR(n,x,delta,theta)
U=rand(1,n);
N=delta*normrnd(0,1,1,n);
x1=x*ones(1,n);
x2=x*ones(1,n);
dw=zeros(1,n);
for i=1:n
y1=x1+N(i)*ones(1,n);
y2=x2+N(i)*ones(1,n);
R1=exp(((x1-theta).^2-(y1-theta).^2)/2);
R2=exp(((x2-theta).^2-(y2-theta).^2)/2);
w1=min(1,R1);
w2=min(1,R2);
dw(i)=N(i)*R1(i)*(R1(i)<1);
I=setdiff((1:n),i);
x1(I)=(U(i)>w1(I)).*x1(I)+(U(i)<=w1(I)).*y1(I);
x2(I)=(U(i)>w2(I)).*x2(I)+(U(i)<=w2(I)).*y2(I);
x2(i)=y2(i);
end
%D=-sum((x1-x2).*dw);
D=-sum((x1.^2-x2.^2).*dw);
end

