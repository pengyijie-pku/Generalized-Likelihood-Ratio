function [g,D]=SAN4(z,num,lambda) 
U=rand(num,6);
l=length(z);
U1=repmat(U(:,1),1,l);
U2=repmat(U(:,2),1,l);
U3=repmat(U(:,3),1,l);
U4=repmat(U(:,4),1,l);
U5=repmat(U(:,5),1,l);
U6=repmat(U(:,6),1,l);
z=repmat(z,num,1);
g1=-log(U1)/lambda(1)-log(U4)/lambda(4)-log(U6)/lambda(6)-z;
g2=-log(U2)/lambda(2)-log(U5)/lambda(5)-log(U6)/lambda(6)-z;
g3=-log(U1)/lambda(1)-log(U3)/lambda(3)-log(U5)/lambda(5)-log(U6)/lambda(6)-z;
g=max(g1,g2);
g=max(g,g3);
D=(g1<=0).*(g2<=0).*(g3<=0).*(-sum(lambda(1:3))+lambda(1)*(-log(U1)/lambda(1))./(-log(U3)/lambda(3)));
end