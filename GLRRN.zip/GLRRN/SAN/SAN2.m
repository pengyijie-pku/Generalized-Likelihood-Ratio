function g=SAN2(z,num,lambda) 
U=rand(6,num);
g1=-log(U(1,:))/lambda(1)-log(U(4,:))/lambda(4)-log(U(6,:))/lambda(6)-z;
g2=-log(U(2,:))/lambda(2)-log(U(5,:))/lambda(5)-log(U(6,:))/lambda(6)-z;
g3=-log(U(1,:))/lambda(1)-log(U(3,:))/lambda(3)-log(U(5,:))/lambda(5)-log(U(6,:))/lambda(6)-z;
g11=-log(U(1,:))/lambda(1)-log(U(6,:))/lambda(6)-z;
g21=g2;
g31=g3;
g12=g1;
g22=-log(U(5,:))/lambda(5)-log(U(6,:))/lambda(6)-z;
g32=g3;
g13=g1;
g23=g2;
g33=-log(U(1,:))/lambda(1)-log(U(5,:))/lambda(5)-log(U(6,:))/lambda(6)-z;
g=(g11<=0).*(g21<=0).*(g31<=0)*lambda(4)+(g12<=0).*(g22<=0).*(g32<=0)*lambda(2)+(g13<=0).*(g23<=0).*(g33<=0)*lambda(3)-sum(lambda(2:4))*(g1<=0).*(g2<=0).*(g3<=0);
end