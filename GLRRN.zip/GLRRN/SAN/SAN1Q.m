function [g,D]=SAN1Q(z,num,lambda) 
  S = sobolset(6,'Skip',1e3,'Leap',1e2);
 S= scramble(S,'MatousekAffineOwen');
 U= net(S,num);
l=length(z);
U1=repmat(U(:,1),1,l);
U2=repmat(U(:,2),1,l);
U3=repmat(U(:,3),1,l);
U4=repmat(U(:,4),1,l);
U5=repmat(U(:,5),1,l);
U6=repmat(U(:,6),1,l);
z=repmat(z,num,1);
g1=-log(U1)/lambda(1)-log(U4)/lambda(4)-log(U6)/lambda(6);
g2=-log(U2)/lambda(2)-log(U5)/lambda(5)-log(U6)/lambda(6);
g3=-log(U1)/lambda(1)-log(U3)/lambda(3)-log(U5)/lambda(5)-log(U6)/lambda(6);
g11=-log(U4)/lambda(4)-log(U6)/lambda(6);
g21=g2;
g31=-log(U3)/lambda(3)-log(U5)/lambda(5)-log(U6)/lambda(6);
g12=g1;
g22=-log(U5)/lambda(5)-log(U6)/lambda(6);
g32=g3;
g=max(g1,g2);
g=max(g,g3);
D=(g11<=z).*(g21<=z).*(g31<=z)*lambda(1)+(g12<=z).*(g22<=z).*(g32<=z)*lambda(2)-sum(lambda(1)+lambda(3))*(g1<=z).*(g2<=z).*(g3<=z);
end