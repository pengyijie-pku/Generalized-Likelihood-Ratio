function [g,D]=SAN3Q(z,num,lambda,delta) 
  S = sobolset(6,'Skip',1e3,'Leap',1e2);
 S= scramble(S,'MatousekAffineOwen');
 U= net(S,num);
 %U=P';
l=length(z);
U1=repmat(U(:,1),1,l);
U2=repmat(U(:,2),1,l);
U3=repmat(U(:,3),1,l);
U4=repmat(U(:,4),1,l);
U5=repmat(U(:,5),1,l);
U6=repmat(U(:,6),1,l);
z=repmat(z,num,1);
g1=-log(U1)/lambda(1)-log(U4)/lambda(4)-log(U6)/lambda(6);
g2=-log(U2)/lambda(2)-log(U5)/lambda(5)-log(U6)/lambda(6);
g3=-log(U1)/lambda(1)-log(U3)/lambda(3)-log(U5)/lambda(5)-log(U6)/lambda(6);
g=max(g1,g2);
g=max(g,g3);
D=((g1<=z+delta).*(g2<=z+delta).*(g3<=z+delta)-(g1<=z).*(g2<=z).*(g3<=z))/delta;
end